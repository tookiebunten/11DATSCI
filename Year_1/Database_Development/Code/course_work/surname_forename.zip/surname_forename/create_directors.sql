.system echo "Inside script <create_directors.sql>"
.system echo "-------------------------------------"