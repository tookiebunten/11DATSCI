.system echo "Inside script <load_movies_actors_data.sql>"
.system echo "--------------------------------------"