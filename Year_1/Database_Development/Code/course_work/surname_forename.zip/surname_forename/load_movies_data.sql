.system echo "Inside script <load_movies_data.sql>"
.system echo "----------------------------------------"