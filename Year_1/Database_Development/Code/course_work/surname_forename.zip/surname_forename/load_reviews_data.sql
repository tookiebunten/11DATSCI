.system echo "Inside script <load_reviews_data.sql>"
.system echo "--------------------------------------------"