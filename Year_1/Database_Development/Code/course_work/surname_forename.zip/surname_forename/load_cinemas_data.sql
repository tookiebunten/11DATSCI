.system echo "Inside script <load_cinemas_data.sql>"
.system echo "------------------------------------------------"