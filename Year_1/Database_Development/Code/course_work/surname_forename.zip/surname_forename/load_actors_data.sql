.system echo "Inside script <load_actors_data.sql>"
.system echo "-------------------------------------"