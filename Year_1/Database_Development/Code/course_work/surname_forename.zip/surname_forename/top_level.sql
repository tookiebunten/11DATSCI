-- you can comment code like this, with a '--'
.system CLS
.system echo "Inside script <top-level.sql>"
.system echo "-----------------------------"
.system echo "=================================="
.system echo "------------KEY ON/OFF------------"
.system echo "=================================="
.system echo "Switching the foreign keys ON"
PRAGMA foreign_keys = ON;

.system echo "=================================="
.system echo "-------------CREATING-------------"
.system echo "=================================="

.read create_actors.sql	
.read create_directors.sql	
.read create_movies.sql
.read create_movies_actors.sql
.read create_cinemas.sql		
.read create_movies_directors.sql
.read create_reviews.sql


--/*
.system echo "=================================="
.system echo "--------------LOADING-------------"
.system echo "=================================="
.read load_actors_data.sql	
.read load_directors_data.sql	
.read load_cinemas_data.sql		
.read load_movies_data.sql
.read load_movies_actors_data.sql
.read load_movies_directors_data.sql
.read load_reviews_data.sql

--*/

--/*
.system echo "=================================="
.system echo "--------------REPORT--------------"
.system echo "=================================="
.read report.sql
--*/

.read top_force_drop.sql

-- INSERT failed: FOREIGN KEY constraint failed
-- You are possibly trying to reference a key in another table, but the key in that table does not exist.

-- INSERT failed: UNIQUE constraint failed:
-- You are possibly trying to insert data into a table, but that data is already there and should be UNIQUE

-- Error: foreign key mismatch - "songs_coverartists" referencing "song"
-- Are you trying to reference a primary key from another table, but in that table you forgot to declare the key PRIMARY KEY
