.system echo "Inside script <create_movies_directors.sql>"
.system echo "---------------------------------------------"