.system echo "Inside script <report.sql>"
.system echo "-----------------------------"

----------------------------------- 1
.system echo "_______"	
.system echo ""
.system echo "List the forename and surname of actors whose forename begins M and whose surname begins with S"

----------------------------------- 2
.system echo "_______"	
.system echo ""
.system echo "List the movies in reverse alphabetical order of the title and limit the output to 5 movies"	


----------------------------------- 3
.system echo "_______"	
.system echo ""
.system echo "List the number of movies that are being shown at the Cameo"	
.system echo ""


----------------------------------- 4
.system echo "_______"	
.system echo ""
.system echo "List the titles of the movies reviewed by 'Rotten Tomatoes'"	
.system echo ""


----------------------------------- 5
.system echo "_______"	
.system echo ""
.system echo "List the percentage of the reviews provided by Film Critic"	
.system echo ""

----------------------------------- 6
.system echo "_______"
.system echo "List the movie titles directed by Scorsese"	
.system echo ""


----------------------------------- 7
.system echo "_______"	
.system echo "List the actors in the Pulp Fiction movie"
.system echo ""



.system echo ""
.system echo "''''END OF REPORT''''"
.system echo "_____________________"
