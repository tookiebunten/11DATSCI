.system echo "Inside script <create_reviews.sql>"
.system echo "----------------------------------"