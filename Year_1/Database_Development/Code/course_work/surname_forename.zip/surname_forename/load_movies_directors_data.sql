.system echo "Inside script <load_movies_directors_data.sql>"
.system echo "-----------------------------------"