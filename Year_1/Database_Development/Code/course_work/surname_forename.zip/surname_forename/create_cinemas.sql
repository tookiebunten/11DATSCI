.system echo "Inside script <create_cinemas.sql>"
.system echo "-----------------------------------------"