.system echo "Inside script <load_directors_data.sql>"
.system echo "--------------------------------------"