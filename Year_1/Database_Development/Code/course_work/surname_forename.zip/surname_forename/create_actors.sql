.system echo "Inside script <create_actors.sql>"
.system echo "--------------------------------"