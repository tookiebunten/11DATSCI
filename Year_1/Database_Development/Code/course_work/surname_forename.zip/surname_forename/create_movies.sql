.system echo "Inside script <create_movies.sql>"
.system echo "----------------------------------"