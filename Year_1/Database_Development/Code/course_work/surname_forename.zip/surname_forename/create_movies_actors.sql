.system echo "Inside script <create_movies_actors.sql>"
.system echo "-----------------------------------"