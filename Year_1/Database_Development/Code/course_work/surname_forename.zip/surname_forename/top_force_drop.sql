.system echo "Turning foreign_keys parameter off"
PRAGMA foreign_keys = OFF;
.system echo "So that these tables:"
.tables
DROP TABLE IF EXISTS actors;           
DROP TABLE IF EXISTS directors;         
DROP TABLE IF EXISTS movies;        
DROP TABLE IF EXISTS movies_actors;        
DROP TABLE IF EXISTS cinemas;         
DROP TABLE IF EXISTS movies_directors;               
DROP TABLE IF EXISTS reviews;
.system echo "...running the .tables command:"
.tables
.system echo "...should result in no tables being displayed"

