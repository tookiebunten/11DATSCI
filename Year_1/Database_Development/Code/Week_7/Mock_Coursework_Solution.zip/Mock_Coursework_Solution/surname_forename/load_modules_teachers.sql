.system echo "Inside script <load_modules_teachers.sql>"
.system echo "-----------------------------------------"

.mode csv
.import data_modules_teachers.csv modules_teachers
.mode list
