.system echo "Inside script <report.sql>"
.system echo "-----------------------------"

.system echo "-"
.system echo "List all columns from tables departments, modules, staff and modules_teachers tables(2)"
SELECT * FROM departments;
SELECT * FROM modules;           
SELECT * FROM staff;          
SELECT * FROM modules_teachers;  

.system echo "-"
.system echo "List the average marks for all marks (2)"
SELECT AVG(mark) FROM marks;

.system echo "-"
.system echo "List the first name, surname and email of staff, ordered by e-mail, but only list 10 of the staff (4)"
SELECT 	
	staff_id, fname, sname, email 
FROM 
	staff 
ORDER BY email 
LIMIT 10;
 
.system echo "-"
.system echo "List the forename and surname of the student and their marks per module 8"
SELECT 
    fname, sname, title, mark
FROM 
    students
	INNER JOIN marks 
		ON students.student_id = marks.student_id
	INNER JOIN modules 
		ON marks.subject_id = modules.module_id	
ORDER BY sname;

.system echo "-"
.system echo "List the title of a subject and the average mark obtained for that subject and order the output from highest to lowest mark 6"
SELECT 
	title,
    AVG(mark)
FROM 
    marks
	INNER JOIN modules 
		ON marks.subject_id = modules.module_id	
	GROUP BY
		title
ORDER BY AVG(mark) DESC;







