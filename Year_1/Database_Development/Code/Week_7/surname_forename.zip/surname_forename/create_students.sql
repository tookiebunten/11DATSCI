.system echo "Inside script <create_students.sql>"
.system echo "----------------------------------"
