.system echo "Inside script <create_departments.sql>"
.system echo "--------------------------------------"

