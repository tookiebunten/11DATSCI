.system echo "Inside script <load_staff.sql>"
.system echo "------------------------------"
