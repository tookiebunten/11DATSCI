.system echo "Inside script <load_departments.sql>"
.system echo "------------------------------------"
