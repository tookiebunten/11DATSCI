.system echo "Inside script <create_marks.sql>"
.system echo "--------------------------------"