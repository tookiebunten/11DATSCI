.system echo "Inside script <report.sql>"
.system echo "-----------------------------"

.system echo "-"
.system echo "List all columns from tables departments, modules, staff and modules_teachers tables(2)"
-- PLEASE PUT YOUR CODE HERE

.system echo "-"
.system echo "List the average marks for all marks (2)"
-- PLEASE PUT YOUR CODE HERE

.system echo "-"
.system echo "List the first name, surname and email of staff, ordered by e-mail, but only list 10 of the staff (4)"
-- PLEASE PUT YOUR CODE HERE

.system echo "-"
.system echo "List the forename and surname of the student and their marks per module 8"
-- PLEASE PUT YOUR CODE HERE

.system echo "-"
.system echo "List the title of a subject and the average mark obtained for that subject and order the output from highest to lowest mark 6"
-- PLEASE PUT YOUR CODE HERE







