.system echo "Inside script <load_modules_teachers.sql>"
.system echo "-----------------------------------------"