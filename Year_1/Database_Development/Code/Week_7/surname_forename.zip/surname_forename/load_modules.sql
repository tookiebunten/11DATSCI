.system echo "Inside script <load_modules.sql>"
.system echo "--------------------------------"
