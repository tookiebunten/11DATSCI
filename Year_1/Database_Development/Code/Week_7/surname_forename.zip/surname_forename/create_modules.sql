.system echo "Inside script <create_modules.sql>"
.system echo "----------------------------------"
