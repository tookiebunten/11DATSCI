.system echo "Inside script <create_modules_teachers.sql>"
.system echo "-------------------------------------------"
