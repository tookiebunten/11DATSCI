.system echo "Inside script <load_marks.sql>"
.system echo "------------------------------"
