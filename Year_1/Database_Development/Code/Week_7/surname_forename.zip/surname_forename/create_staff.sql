.system echo "Inside script <create_staff.sql>"
.system echo "--------------------------------"