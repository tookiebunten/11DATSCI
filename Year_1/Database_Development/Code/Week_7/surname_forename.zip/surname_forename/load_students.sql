.system echo "Inside script <load_students.sql>"
.system echo "---------------------------------"
